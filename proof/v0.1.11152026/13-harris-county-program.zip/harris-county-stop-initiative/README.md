# Harris County S.T.O.P. Initiative

The Stop Theft of Property program for Harris County, Texas, ready to put online.
Made from the open-source S.T.O.P. tool (v0.1.11152026, 2026-11-15): https://github.com/temperne/Open-Pgp-Registrar

- `public/index.html`: the whole program in one file. It works on its own: open it in a
  browser, or put it on any web server. Its defaults: Harris County, Texas; deeds are
  recorded with the Harris County Clerk.
- `src/index.ts`, `wrangler.toml`, `package.json`: a Cloudflare Worker that serves it,
  relays its signing rooms (Sign together) and counts page loads, downloads and rooms by
  country (no tracking in the page).

## Put it online with Cloudflare (free plan)

```sh
npm install
npx wrangler login     # once
npx wrangler deploy
```

It will be at https://harris-county-stop-initiative.<your-account>.workers.dev/ (or a custom domain you add in
Cloudflare). This copy was made for https://harris-county-stop.example.workers.dev/.

Sign together: runs at this copy's own address, https://harris-county-stop.example.workers.dev, through the Worker here. It works only when the page is loaded from exactly that address.
If the address differs, make a new copy with the right address from the program's
"Change county or state" panel (link builder).

Every page and PDF says the program is proposed and not an official county form until the
county adopts it (change `status` in the source's `src/brand.ts` and rebuild).
