# Harris County S.T.O.P. Initiative

The Stop Theft of Property program for Harris County, Texas, ready to put online.
Made from the open-source S.T.O.P. tool (v0.1.11152026, 2026-11-16): https://github.com/temperne/Open-Pgp-Registrar

- `public/index.html`: the whole program in one file. It works on its own: open it in a
  browser, or put it on any web server. Its defaults: Harris County, Texas; deeds are
  recorded with the Harris County Clerk.
- `src/index.ts`, `wrangler.toml`, `package.json`: a Cloudflare Worker that serves it,
  relays its signing rooms (Sign together) and counts page loads, downloads and rooms by
  country (no tracking in the page).

## Put it online with Cloudflare (free plan)

```sh
npm install
npx wrangler login     # once
npx wrangler deploy
```

It will be at https://harris-county-stop-initiative.<your-account>.workers.dev/ (or a custom domain you add in
Cloudflare). This copy was made for https://harris-county-stop.example.workers.dev/.

Sign together: this copy doesn't run signing rooms; its Sign together section sends people to https://pimastopinitiative.jasonajensen.workers.dev, where they work. (You can still deploy the Worker to serve the page and count its use.)
If the address differs, make a new copy with the right address from the program's
"Change county or state" panel (link builder).

## Check that this is the published file

Published by Harris County Clerk Office, Chief Deputy Clerk. `public/index.html` is signed with the publisher's OpenPGP key
(fingerprint F5C861120C34FFA911C1D0BD74C2AF5849DC1487). Compare that fingerprint with the one in the
publisher's signed release statement (PDF), then:

```sh
gpg --import publisher-key.asc
gpg --verify index.html.sig public/index.html
sha256sum public/index.html      # must match the statement
```

Every page and PDF says the program is proposed and not an official county form until the
county adopts it (change `status` in the source's `src/brand.ts` and rebuild).
